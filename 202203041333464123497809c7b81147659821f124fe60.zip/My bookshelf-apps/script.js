let books = [];

function makeBook(makeBook) {
    makeBook.preventDefault();
    const textTitle = document.querySelector("#inputBookTitle"),
    textAuthor = document.querySelector("#inputBookAuthor"),
    textYear= document.querySelector("#inputBookYear"),
    textIComp = document.querySelector("#inputBookIsComplete"),
    nilai = {

        id:+new Date,
        title:textTitle.value,
        author:textAuthor.value,
        year:textYear.value,
        isComplete:textIComp.checked
        };

    console.log(nilai),
    books.push(nilai),
    document.dispatchEvent(new Event("bookShelf"))
}

function addBook(books) {
    const inComplete = document.querySelector("#incompleteBookshelfList"),
    complete = document.querySelector("#completeBookshelfList");

    inComplete.innerHTML = "",
    complete.innerHTML = "";

    for (const nilai of books) {
        const books = document.createElement("article");
        books.classList.add("book_item");
        const textTitle = document.createElement("h2");
        textTitle.innerText = nilai.title;
        const textAuthor = document.createElement("p");
        textAuthor.innerText = "Penulis: " +nilai.author;
        const textYear = document.createElement("p");

        if (
            textYear.innerText = "Tahun: "+nilai.year,
            books.appendChild(textTitle),
            books.appendChild(textAuthor),
            books.appendChild(textYear),
            nilai.isComplete) {
                const act = document.createElement("div");
                act.classList.add("action");
                const btn = document.createElement("button");
                btn.id = nilai.id,
                btn.innerText = "Belum Selesai dibaca",
                btn.classList.add("green"),
                btn.addEventListener("click", unChecked);
                const btnRemove = document.createElement("button");
                btnRemove.id = nilai.id,
                btnRemove.innerText = "Hapus buku",
                btnRemove.classList.add("red"),
                btnRemove.addEventListener("click", removeFromComplete),
                act.appendChild(btn),
                act.appendChild(btnRemove),
                books.appendChild(act),
                complete.appendChild(books)
        } else {
                const divAct = document.createElement("div");
                divAct.classList.add("action");

                const divBtn = document.createElement("button");
                divBtn.id = nilai.id,
                divBtn.innerText = "Selesai dibaca",
                divBtn.classList.add("green"),
                divBtn.addEventListener("click", checkedBtn);

                const divBtnA = document.createElement("button");
                divBtnA.id = nilai.id,
                divBtnA.innerText = "Hapus buku",
                divBtnA.classList.add("red"),
                divBtnA.addEventListener("click", removeFromComplete),
                divAct.appendChild(divBtn),
                divAct.appendChild(divBtnA),
                books.appendChild(divAct),
                inComplete.appendChild(books)
        }
    }
}


function searchBook(makeBook) {
    makeBook.preventDefault();

    const searchTitle = document.querySelector("#searchBookTitle");
    query = searchTitle.value,
    query?addBook(books.filter((function(books) {
        return books.title.toLowerCase().includes(query.toLowerCase())
    }))): addBook(books)
}


function unChecked(makeBook) {
    const check = Number(makeBook.target.id),
    textAuthor = books.findIndex((function(books) {
        return books.id==check
    }));
    -1!==textAuthor&&(books[textAuthor] = {
        ...books[textAuthor],
        isComplete:!1
    },
    document.dispatchEvent(new Event("bookShelf"))
    )
}

function removeFromComplete(makeBook) {
    const check = Number(makeBook.target.id),
    textAuthor = books.findIndex((function(books) {
        return books.id==check
    }));
    -1!==textAuthor&&(books.splice(textAuthor,1),
    document.dispatchEvent(new Event("bookShelf"))
    )
}

function reverse() {
    !function(books) {
        localStorage.setItem("books",JSON.stringify(books))
    }
    (books),addBook(books)
}

window.addEventListener("load", (function() {
    books = JSON.parse(localStorage.getItem("books"))||[],addBook(books);
    const inputBook = document.querySelector("#inputBook"),
    search = document.querySelector("#searchBook");

    inputBook.addEventListener("submit", makeBook),
    search.addEventListener("submit", searchBook),
    document.addEventListener("bookShelf", reverse)
}))

function checkedBtn(makeBook) {
    const check = Number(makeBook.target.id),
    textAuthor = books.findIndex((function (books) {
        return books.id===check
    }));
    -1!==textAuthor&&(books[textAuthor] = {
        ...books[textAuthor],
        isComplete:!0
        },
    document.dispatchEvent(new Event("bookShelf"))
    )
    alert("Selamat! Anda telah selesai membaca Buku:)")
}